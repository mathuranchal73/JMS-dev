package com.sms.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import com.sms.model.MailObject;

public class MailItemProcessor implements ItemProcessor<MailObject, MailObject>{

	
	private static final Logger log = LoggerFactory.getLogger(MailItemProcessor.class);

	@Override
	public MailObject process(final MailObject item) throws Exception {
		
		final String toemail = item.gettoemail().toUpperCase();
        final String subject = item.getSubject().toUpperCase();
        final String text= item.getText().toUpperCase();
        
        final MailObject transformedMail = new MailObject(toemail, subject,text);
        log.info("Converting (" + item + ") into (" + transformedMail + ")");
		// TODO Auto-generated method stub
		return transformedMail;
	}
	
	
}
